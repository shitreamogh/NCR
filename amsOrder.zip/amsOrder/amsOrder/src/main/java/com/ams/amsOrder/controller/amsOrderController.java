package com.ams.amsOrder.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ams.amsOrder.message.responseMessage;
import com.ams.amsOrder.model.data;
import com.ams.amsOrder.service.amsOrderService;

@Controller
@RequestMapping("/amsOrder")
public class amsOrderController {
	@Autowired
	amsOrderService AOService;
	public data d;
	
	@PostMapping("/insert")
	public ResponseEntity<responseMessage> insertAmsOrder(@RequestBody data d){
		this.d = d;
		String message = "";
		AOService.insert(d);
		message = "Uploaded the ams_Order successfully: ";
		return ResponseEntity.status(HttpStatus.OK).body(new responseMessage(message));
		
	}

}
