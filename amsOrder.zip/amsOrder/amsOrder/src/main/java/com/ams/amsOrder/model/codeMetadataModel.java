package com.ams.amsOrder.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "code_metadata")
public class codeMetadataModel {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Column(name = "description")
	private String description;
	@Column(name = "language_id")
	private String language_id;
	@Column(name="code_id")
	private long code_id;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLanguage_id() {
		return language_id;
	}
	public void setLanguage_id(String language_id) {
		this.language_id = language_id;
	}
	public long getCode_id() {
		return code_id;
	}
	public void setCode_id(long code_id) {
		this.code_id = code_id;
	}
	public codeMetadataModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public codeMetadataModel(long id, String description, String language_id, long code_id) {
		super();
		this.id = id;
		this.description = description;
		this.language_id = language_id;
		this.code_id = code_id;
	}
	@Override
	public String toString() {
		return "codeMetadataModel [id=" + id + ", description=" + description + ", language_id=" + language_id
				+ ", code_id=" + code_id + "]";
	}
	
	
	

}
