package com.ams.amsOrder.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "country")
public class productCountry {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Column(name = "description")
	private String description;
	@Column(name = "code")
	private String code; //(user/text)
	@Column(name = "loc_optimization")
	private String loc_optimization;
	@Column(name = "is_p360_applicable")
	private String is_p360_applicable;
	@Column(name = "apac_country_code")
	private String apac_country_code;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getLoc_optimization() {
		return loc_optimization;
	}
	public void setLoc_optimization(String loc_optimization) {
		this.loc_optimization = loc_optimization;
	}
	public String getIs_p360_applicable() {
		return is_p360_applicable;
	}
	public void setIs_p360_applicable(String is_p360_applicable) {
		this.is_p360_applicable = is_p360_applicable;
	}
	public String getApac_country_code() {
		return apac_country_code;
	}
	public void setApac_country_code(String apac_country_code) {
		this.apac_country_code = apac_country_code;
	}
	public productCountry() {
		super();
		// TODO Auto-generated constructor stub
	}
	public productCountry(long id, String description, String code, String loc_optimization, String is_p360_applicable,
			String apac_country_code) {
		super();
		this.id = id;
		this.description = description;
		this.code = code;
		this.loc_optimization = loc_optimization;
		this.is_p360_applicable = is_p360_applicable;
		this.apac_country_code = apac_country_code;
	}
	
	

}
