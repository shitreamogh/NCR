package com.ams.amsOrder.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsOrder.model.orderCommissionDetail;

@Repository
public interface orderCommissionDetailRepository extends JpaRepository<orderCommissionDetail, Long> {
	@Transactional
	@Modifying
	@Query(value = "insert into commission_detail(id, commission_type, country_id)"
			+ "VALUES(:id, :commission_type, :country_id)", nativeQuery = true)//id, country_id, location_hierarchy_level, location_hierarchy_name, country_name, apac_hierarchy_name
	public void insertCommissionDetails(@Param("id") long id,  @Param("commission_type") String commission_type, @Param("country_id") long country_id);
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from commission_detail", nativeQuery = true)//
	public int selectCommissionDetails();

}
