package com.ams.amsOrder.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsOrder.model.orderCountry;

@Repository
public interface orderCountryRepository extends JpaRepository<orderCountry, Long> {
	@Transactional
	@Modifying
	@Query(value = "insert into country(id, code, description, android_app_name, ios_app_name, server_api_key, kezzler_api_url, "
			+ "kezzler_header, unit_of_measure, integration_type, is_duplicate_qr_allowed) "
			+ "VALUES (:id, :code, :description, :android_app_name, :ios_app_name, :server_api_key, :kezzler_api_url, "
			+ ":kezzler_header, :unit_of_measure, :integration_type, :is_duplicate_qr_allowed)", nativeQuery = true)// currancy, dynamic_commission, after app_version
	public void insertcountry(@Param("id") long id, @Param("code") String code,@Param("description") String description,@Param("android_app_name") String android_app_name,
			@Param("ios_app_name") String ios_app_name,@Param("server_api_key") String server_api_key,@Param("kezzler_api_url") String kezzler_api_url,
			@Param("kezzler_header") String kezzler_header,@Param("unit_of_measure") String unit_of_measure,@Param("integration_type") String integration_type,
			@Param("is_duplicate_qr_allowed") boolean is_duplicate_qr_allowed);
	
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from country", nativeQuery = true)//
	public int selectCountry();

}
