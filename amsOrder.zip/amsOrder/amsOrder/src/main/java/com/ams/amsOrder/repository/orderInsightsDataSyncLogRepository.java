package com.ams.amsOrder.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsOrder.model.orderInsightsDataSyncLog;

@Repository
public interface orderInsightsDataSyncLogRepository extends JpaRepository<orderInsightsDataSyncLog, Long> {
	@Transactional
	@Modifying
	@Query(value = "insert into insights_data_sync_log(id, insights_data_sync_date, api_key, country_id, old_id)"
			+ "VALUES(:id, :insights_data_sync_date, :api_key, :country_id, :old_id)", nativeQuery = true)
	public void insertInsightsDataSyncLog(@Param("id") long id, @Param("insights_data_sync_date") Date insights_data_sync_date, @Param("api_key") String api_key, @Param("country_id") long country_id, @Param("old_id") long old_id);
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from insights_data_sync_log", nativeQuery = true)//
	public int selectInsightsDataSyncLog();

}
