package com.ams.amsOrder.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ams.amsOrder.model.data;
import com.ams.amsOrder.repository.orderCommissionDetailRepository;
import com.ams.amsOrder.repository.orderCountryRepository;
import com.ams.amsOrder.repository.orderInsightsDataSyncLogRepository;

@Service
public class amsOrderService {
	 @Autowired
	 orderCountryRepository OCrepository;
	 @Autowired
	 orderInsightsDataSyncLogRepository OIDSLrepository;
	 @Autowired
	 orderCommissionDetailRepository OCDrepository;
	 
	 public void insert(data d) {
		//insert in ams_order country
	      long country_id = d.order_country.get(0).getId();
	      OCrepository.insertcountry(d.order_country.get(0).getId(), d.order_country.get(0).getCode(), d.order_country.get(0).getDescription(), d.order_country.get(0).getAndroid_app_name(), d.order_country.get(0).getIos_app_name(), d.order_country.get(0).getServer_api_key(), d.order_country.get(0).getKezzler_api_url(), d.order_country.get(0).getKezzler_header(), d.order_country.get(0).getUnit_of_measure(), d.order_country.get(0).getIntegration_type(), d.order_country.get(0).isIs_duplicate_qr_allowed());
	      
	      //insert in ams_order insights_data_sync_log
	      int i = 0;
	      while(i < d.order_insights_data_sync_logs.size()) {
	    	  d.order_insights_data_sync_logs.get(i).setId(OIDSLrepository.selectInsightsDataSyncLog()+1);
	    	  OIDSLrepository.insertInsightsDataSyncLog(d.order_insights_data_sync_logs.get(i).getId(), d.order_insights_data_sync_logs.get(i).getInsights_data_sync_date(), d.order_insights_data_sync_logs.get(i).getApi_key(), d.order_insights_data_sync_logs.get(i).getCountry_id(), d.order_insights_data_sync_logs.get(i).getOld_id());
	    
	    	 i++;
	      }
	      
	      //insert in commission_details
	      i = 0;
	      while(i < d.order_commission_details.size()) {
	    	  d.order_commission_details.get(i).setId(OCDrepository.selectCommissionDetails()+1);
	    	  OCDrepository.insertCommissionDetails(d.order_commission_details.get(i).getId(), d.order_commission_details.get(i).getCommission_type(), d.order_commission_details.get(i).getCountry_id());
	    
	    	 i++;
	      }
		 
	 }

}
//<dependency>
//<groupId>org.springframework.cloud</groupId>
//<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
//</dependency>