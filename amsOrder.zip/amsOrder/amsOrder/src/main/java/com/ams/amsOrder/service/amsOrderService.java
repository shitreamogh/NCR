package com.ams.amsOrder.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ams.amsOrder.model.data;
import com.ams.amsOrder.repository.orderCommissionDetailRepository;
import com.ams.amsOrder.repository.orderCountryRepository;
import com.ams.amsOrder.repository.orderInsightsDataSyncLogRepository;

@Service
public class amsOrderService {
	 @Autowired
	 orderCountryRepository OCrepository;
	 @Autowired
	 orderInsightsDataSyncLogRepository OIDSLrepository;
	 @Autowired
	 orderCommissionDetailRepository OCDrepository;
	 
	 public void insert(data d) {
		//insert in ams_order country
	      long country_id = d.orderCountry.get(0).getId();
	      OCrepository.insertcountry(d.orderCountry.get(0).getId(), d.orderCountry.get(0).getCode(), d.orderCountry.get(0).getDescription(), d.orderCountry.get(0).getAndroid_app_name(), d.orderCountry.get(0).getIos_app_name(), d.orderCountry.get(0).getServer_api_key(), d.orderCountry.get(0).getKezzler_api_url(), d.orderCountry.get(0).getKezzler_header(), d.orderCountry.get(0).getUnit_of_measure(), d.orderCountry.get(0).getIntegration_type(), d.orderCountry.get(0).isIs_duplicate_qr_allowed());
	      
	      //insert in ams_order insights_data_sync_log
	      int i = 0;
	      while(i < d.orderInsightsDataSyncLogs.size()) {
	    	  d.orderInsightsDataSyncLogs.get(i).setId(OIDSLrepository.selectInsightsDataSyncLog()+1);
	    	  OIDSLrepository.insertInsightsDataSyncLog(d.orderInsightsDataSyncLogs.get(i).getId(), d.orderInsightsDataSyncLogs.get(i).getInsights_data_sync_date(), d.orderInsightsDataSyncLogs.get(i).getApi_key(), d.orderInsightsDataSyncLogs.get(i).getCountry_id(), d.orderInsightsDataSyncLogs.get(i).getOld_id());
	    
	    	 i++;
	      }
	      
	      //insert in commission_details
	      i = 0;
	      while(i < d.orderCommissionDetails.size()) {
	    	  d.orderCommissionDetails.get(i).setId(OCDrepository.selectCommissionDetails()+1);
	    	  OCDrepository.insertCommissionDetails(d.orderCommissionDetails.get(i).getId(), d.orderCommissionDetails.get(i).getCommission_type(), d.orderCommissionDetails.get(i).getCountry_id());
	    
	    	 i++;
	      }
		 
	 }

}
//<dependency>
//<groupId>org.springframework.cloud</groupId>
//<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
//</dependency>