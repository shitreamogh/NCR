package com.ams.amsProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmsProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmsProductApplication.class, args);
	}

}
