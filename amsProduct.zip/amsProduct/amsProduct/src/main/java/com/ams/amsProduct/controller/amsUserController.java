package com.ams.amsProduct.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ams.amsProduct.message.responseMessage;
import com.ams.amsProduct.model.data;
import com.ams.amsProduct.service.amsProductService;

@Controller
@RequestMapping("/amsProduct")
public class amsUserController {
	@Autowired
	amsProductService APService;
	public data d;
	
	@PostMapping("/insert")
	public ResponseEntity<responseMessage> insertAmsProduct(@RequestBody data d){
		this.d = d;
		String message = "";
		APService.insert(d);
		message = "Uploaded the ams_User successfully: ";
		return ResponseEntity.status(HttpStatus.OK).body(new responseMessage(message));
		
	}

}
