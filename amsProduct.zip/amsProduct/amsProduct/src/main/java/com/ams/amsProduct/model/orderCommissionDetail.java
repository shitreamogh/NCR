package com.ams.amsProduct.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "commission_details")
public class orderCommissionDetail {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Column(name = "commission_type")
	private String commission_type;
	@Column(name="country_id")
	private long country_id;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCommission_type() {
		return commission_type;
	}
	public void setCommission_type(String commission_type) {
		this.commission_type = commission_type;
	}
	public long getCountry_id() {
		return country_id;
	}
	public void setCountry_id(long country_id) {
		this.country_id = country_id;
	}
	public orderCommissionDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public orderCommissionDetail(long id, String commission_type, long country_id) {
		super();
		this.id = id;
		this.commission_type = commission_type;
		this.country_id = country_id;
	}
	
	

}
