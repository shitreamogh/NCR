package com.ams.amsProduct.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "insights_data_sync_log")
public class orderInsightsDataSyncLog {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insights_data_sync_date", nullable = false)
	private Date insights_data_sync_date;
	@Column(name = "api_key")
	private String api_key;
	@Column(name="country_id")
	private long country_id;
	@Column(name="old_id")
	private long old_id;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Date getInsights_data_sync_date() {
		return insights_data_sync_date;
	}
	public void setInsights_data_sync_date(Date insights_data_sync_date) {
		this.insights_data_sync_date = insights_data_sync_date;
	}
	public String getApi_key() {
		return api_key;
	}
	public void setApi_key(String api_key) {
		this.api_key = api_key;
	}
	public long getCountry_id() {
		return country_id;
	}
	public void setCountry_id(long country_id) {
		this.country_id = country_id;
	}
	public long getOld_id() {
		return old_id;
	}
	public void setOld_id(long old_id) {
		this.old_id = old_id;
	}
	public orderInsightsDataSyncLog() {
		super();
		// TODO Auto-generated constructor stub
	}
	public orderInsightsDataSyncLog(long id, Date insights_data_sync_date, String api_key, long country_id,
			long old_id) {
		super();
		this.id = id;
		this.insights_data_sync_date = insights_data_sync_date;
		this.api_key = api_key;
		this.country_id = country_id;
		this.old_id = old_id;
	}
	

}
