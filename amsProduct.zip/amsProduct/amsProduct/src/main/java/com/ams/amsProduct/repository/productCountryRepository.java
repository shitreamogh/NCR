package com.ams.amsProduct.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsProduct.model.productCountry;

@Repository
public interface productCountryRepository extends JpaRepository<productCountry, Long>{
	@Transactional
	@Modifying
	@Query(value = "insert into country(id, description, code, loc_optimization, is_p360_applicable, apac_country_code) "
			+ "VALUES (:id, :description, :code, :loc_optimization, :is_p360_applicable, :apac_country_code)", nativeQuery = true)
	public void insertcountry(@Param("id") long id, @Param("description") String description, @Param("code") String code,
			@Param("loc_optimization") String loc_optimization,@Param("is_p360_applicable") String is_p360_applicable,
			@Param("apac_country_code") String apac_country_code);
	
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from country", nativeQuery = true)//
	public int selectCountry();

}
