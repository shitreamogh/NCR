package com.ams.amsProduct.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ams.amsProduct.model.data;
import com.ams.amsProduct.repository.productCountryRepository;
import com.ams.amsProduct.repository.productInsightsDataSyncLogRepository;

@Service
public class amsProductService {
	@Autowired
	 productCountryRepository PCrepository;
	 @Autowired
	 productInsightsDataSyncLogRepository PIDSLRepository;
	 
	 public void insert(data d) {
		 //insert in ams_product country
	      PCrepository.insertcountry(d.productCountry.get(0).getId(), d.productCountry.get(0).getDescription(), d.productCountry.get(0).getCode(), d.productCountry.get(0).getLoc_optimization(), d.productCountry.get(0).getIs_p360_applicable(), d.productCountry.get(0).getApac_country_code());
	     //insert in insights_data_sync_log
		      int i = 0;
		      while(i < d.productInsightsDataSyncLogs.size()) {
		    	  d.productInsightsDataSyncLogs.get(i).setId(PIDSLRepository.selectInsightsDataSyncLog()+1);
		    	  PIDSLRepository.insertInsightsDataSyncLog(d.productInsightsDataSyncLogs.get(i).getId(), d.productInsightsDataSyncLogs.get(i).getInsights_data_sync_date(), d.productInsightsDataSyncLogs.get(i).getCountry_id(), d.productInsightsDataSyncLogs.get(i).getOld_id());
			    
			    	 i++;
				}
	 }

}

//<dependency>
//<groupId>org.springframework.cloud</groupId>
//<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
//</dependency>
