package com.ams.amsUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmsUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmsUserApplication.class, args);
	}

}
