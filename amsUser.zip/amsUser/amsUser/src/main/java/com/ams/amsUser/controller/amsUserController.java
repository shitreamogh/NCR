package com.ams.amsUser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ams.amsUser.message.responseMessage;
import com.ams.amsUser.model.data;
import com.ams.amsUser.service.amsUserService;

@Controller
@RequestMapping("/amsUser")
public class amsUserController {
	@Autowired
	amsUserService AUService;
	public data d;
	
	@GetMapping("/getCountryId")
	public ResponseEntity<Integer> getCountryId() {
		int i = AUService.getId();
		return new ResponseEntity<>(i, HttpStatus.OK);
	}
	@PostMapping("/checkDuplicate")
	public ResponseEntity<Boolean> checkDuplicate(@RequestBody data d) {
		boolean i = AUService.isDuplicate(d);
		return new ResponseEntity<Boolean>(i, HttpStatus.OK);
	}
//	@PostConstruct
	@PostMapping("/insert")
	public ResponseEntity<responseMessage> insertAmsUser(@RequestBody data d){
		this.d = d;
		String message = "";
		AUService.insert(d);
		message = "Uploaded the ams_User successfully: ";
		return ResponseEntity.status(HttpStatus.OK).body(new responseMessage(message));
		
	}

}
