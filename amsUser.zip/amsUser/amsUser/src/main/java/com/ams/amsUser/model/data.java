package com.ams.amsUser.model;

import java.util.List;

public class data {
	public List<countryModel> country;
	public List<codeCountryModel> codeCountry;
	public List<locationMetadataModel> locationMetadata;
	public List<codeModel> code;
	public List<codeMetadataModel> codeMetadata;
	public List<specialCampaignMasterModel> specialCampaignMaster;
	public List<appBuildInfoModel> appBuildInfo;
	public List<insightsDataSyncLogModel> insightsDataSyncLog;
	public List<productCountry> productCountry;
	public List<productInsightsDataSyncLog> productInsightsDataSyncLogs;
	public List<orderCountry> orderCountry;
	public List<orderInsightsDataSyncLog> orderInsightsDataSyncLogs;
	public List<orderCommissionDetail> orderCommissionDetails;
	
	public data() {
		super();
		// TODO Auto-generated constructor stub
	}

	public data(List<countryModel> country, List<codeCountryModel> codeCountry,
			List<locationMetadataModel> locationMetadata, List<codeModel> code, List<codeMetadataModel> codeMetadata,
			List<specialCampaignMasterModel> specialCampaignMaster, List<appBuildInfoModel> appBuildInfo,
			List<insightsDataSyncLogModel> insightsDataSyncLog,
			List<productCountry> productCountry,
			List<productInsightsDataSyncLog> productInsightsDataSyncLogs,
			List<orderCountry> orderCountry,
			List<orderInsightsDataSyncLog> orderInsightsDataSyncLogs,
			List<orderCommissionDetail> orderCommissionDetails) {
		super();
		this.country = country;
		this.codeCountry = codeCountry;
		this.locationMetadata = locationMetadata;
		this.code = code;
		this.codeMetadata = codeMetadata;
		this.specialCampaignMaster = specialCampaignMaster;
		this.appBuildInfo = appBuildInfo;
		this.insightsDataSyncLog = insightsDataSyncLog;
		this.productCountry = productCountry;
		this.productInsightsDataSyncLogs = productInsightsDataSyncLogs;
		this.orderCountry = orderCountry;
		this.orderInsightsDataSyncLogs = orderInsightsDataSyncLogs;
		this.orderCommissionDetails = orderCommissionDetails;
	}

	
	
}
