package com.ams.amsUser.repository;

import java.util.Date;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsUser.model.appBuildInfoModel;

@Repository
public interface appBuildInfoModelRepository extends JpaRepository<appBuildInfoModel, Long> {
	@Transactional
	@Modifying
	@Query(value = "insert into app_build_info(id, created_date, last_updated_date, app_version, build_description, is_force_update, operating_system, country_id, old_id)"
			+ "VALUES(:id, :created_date, :last_updated_date, :app_version, :build_description, :is_force_update, :operating_system, :country_id, :old_id)", nativeQuery = true)
	public void insertAppBuildInfo(@Param("id") long id, @Param("created_date") Date created_date, @Param("last_updated_date") Date last_updated_date, @Param("app_version") double app_version, @Param("build_description") String build_description, @Param("is_force_update") boolean is_force_update, @Param("operating_system") String operating_system, @Param("country_id") long country_id, @Param("old_id") double old_id);
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from app_build_info", nativeQuery = true)//
	public int selectAppBuildInfo();

}
