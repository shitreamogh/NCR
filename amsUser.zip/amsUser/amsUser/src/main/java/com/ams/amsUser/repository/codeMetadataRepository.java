package com.ams.amsUser.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsUser.model.codeMetadataModel;

@Repository
public interface codeMetadataRepository extends JpaRepository<codeMetadataModel, Long>{
	@Transactional
	@Modifying
	@Query(value = "insert into code_metadata(id, description, language_id, code_id)"
			+ "VALUES(:id, :description, :language_id, :code_id)", nativeQuery = true)//id, country_id, code_id
	public void insertCodeMetadata(@Param("id") long id, @Param("description") String description, 
			@Param("language_id") String language_id, @Param("code_id") long code_id);
	@Qualifier("ams_user")
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from code_metadata", nativeQuery = true)//
	public int selectCodeMetadata();
	@Transactional
//	@Modifying
	@Query(value = "select min(id) from code where (value like :value and code like :country_id and id > :pivote)", nativeQuery = true)//
	public int selectCodeID(@Param("value") String value, @Param("country_id") String country_id, @Param("pivote") long pivote);

}
