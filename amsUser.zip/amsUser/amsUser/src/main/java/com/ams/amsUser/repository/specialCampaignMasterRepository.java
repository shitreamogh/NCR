package com.ams.amsUser.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.amsUser.model.specialCampaignMasterModel;

@Repository
public interface specialCampaignMasterRepository extends JpaRepository<specialCampaignMasterModel, Long>{
	@Transactional
	@Modifying
	@Query(value = "insert into special_campaign_master(id, country_id, version, campaign_name, campaign_desc, created_date, last_updated_date, created_by, last_updated_by)"
			+ "VALUES(:id, :country_id, :version, :campaign_name, :campaign_desc, :created_date, :last_updated_date, :created_by, :last_updated_by)", nativeQuery = true)
	public void insertSpecialCampaignMaster(@Param("id") long id, @Param("country_id") long country_id, @Param("version") double version, @Param("campaign_name") String campaign_name, @Param("campaign_desc") String campaign_desc, @Param("created_date") Date created_date, @Param("last_updated_date") Date last_updated_date, @Param("created_by") double created_by, @Param("last_updated_by") double last_updated_by);
	@Transactional
//	@Modifying
	@Query(value = "select max(id) from special_campaign_master", nativeQuery = true)//
	public int selectSpecialCampaignMaster();

}
