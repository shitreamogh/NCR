package com.ams.amsUser.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ams.amsUser.model.data;
import com.ams.amsUser.repository.appBuildInfoModelRepository;
import com.ams.amsUser.repository.codeCountryModelRepository;
import com.ams.amsUser.repository.codeMetadataRepository;
import com.ams.amsUser.repository.codeModelRepository;
import com.ams.amsUser.repository.countryModelRepository;
import com.ams.amsUser.repository.insightsDataSyncLogModelRepository;
import com.ams.amsUser.repository.locationMetadataModelRepository;
import com.ams.amsUser.repository.specialCampaignMasterRepository;

@Service
public class amsUserService {
	@Autowired
	  countryModelRepository CMrepository;
	 @Autowired
	  codeCountryModelRepository CCMrepository;
	 @Autowired
	  locationMetadataModelRepository LMrepository;
	 @Autowired
	  codeModelRepository COMrepository;
	 @Autowired
	  codeMetadataRepository COMMrepository;
	 @Autowired
	 specialCampaignMasterRepository SCMMrepository;
	 @Autowired
	 appBuildInfoModelRepository ABIMrepository;
	 @Autowired
	 insightsDataSyncLogModelRepository IDSLMrepository;
	
	 public void insert(data d) {
		// TODO Auto-generated method stub
	      long country_id = d.country.get(0).getId();
	      //insert data in country
			      CMrepository.insertcountry(d.country.get(0).getId(), d.country.get(0).getCode(), d.country.get(0).getDescription(), 
			    		  d.country.get(0).getLanguage(), d.country.get(0).getFarmer_language(), d.country.get(0).getApac_code(), 
			    		  d.country.get(0).getUnit_of_measure(), d.country.get(0).getLoc_optimization(), d.country.get(0).getUnified_app(), 
			    		  d.country.get(0).getCurrency(), d.country.get(0).getCountry_code(), d.country.get(0).getS3_location(), 
			    		  d.country.get(0).getApac_url(), d.country.get(0).getDynamic_commission(), d.country.get(0).isMaintenance_flag(), 
			    		  d.country.get(0).getDc_apac_url(), d.country.get(0).getAgro_url(), d.country.get(0).getAgro_username(), 
			    		  d.country.get(0).getAgro_password(), d.country.get(0).getSender_id(), d.country.get(0).getZone_id(), 
			    		  d.country.get(0).getIs_p360_applicable(), d.country.get(0).getApp_version(), d.country.get(0).getApac_country_code(), 
			    		  d.country.get(0).getCurrancy(), d.country.get(0).getDynamic_commision(), d.country.get(0).isMultilingual_enabled(), 
			    		  d.country.get(0).getIs_legal_agreement_enabled());
			      
			      //Insert Data in code_country
			      int i = 0;
			      while(i < d.code_country.size()) {
			    	  d.code_country.get(i).setId(CCMrepository.selectCodeCountry()+1);
			    	  CCMrepository.insertCodeCountry(d.code_country.get(i).getId(), d.code_country.get(i).getCountry_id(), d.code_country.get(i).getCode_id());//.concat(String.valueOf(country_id))
			    	  i++;
			      }
			      
			      //insert data in location_metadata
			      i = 0;
			      while(i < d.location_metadata.size()) {
			    	  d.location_metadata.get(i).setId(LMrepository.selectLocationMetadata()+1);
			    	  LMrepository.insertLocationMetadata(d.location_metadata.get(i).getId(), d.location_metadata.get(i).getCountry_id(), d.location_metadata.get(i).getLocation_hierarchy_level(), d.location_metadata.get(i).getLocation_hierarchy_name(), d.location_metadata.get(i).getCountry_name(), d.location_metadata.get(i).getApac_hierarchy_name());
			    	  i++;
			      }
			      //insert data in code
			      i = 0;
			      while(i < d.code.size()) {
			    	  d.code.get(i).setId(COMrepository.selectCode()+1);
			    	  COMrepository.insertCode(d.code.get(i).getId(), d.code.get(i).getCode(), d.code.get(i).getDescription(), d.code.get(i).getValue(), d.code.get(i).getLanguage());//d.code.get(i).getCode().concat(String.valueOf(country_id))
			    
			    	 i++;
			      }
			      //insert in code_metadata
			      i = 0;
			      long pivote = 0;
			      while(i < d.code_metadata.size()) {
			    	  if(d.country.get(0).isMultilingual_enabled()) {
			    		  d.code_metadata.get(i).setId(COMMrepository.selectCodeMetadata()+1);
			    		  d.code_metadata.get(i).setCode_id(COMMrepository.selectCodeID("%".concat(d.code_metadata.get(i).getDescription()), "%".concat(String.valueOf(country_id)), pivote));
			    		  pivote = d.code_metadata.get(i).getCode_id()-1;
			    		  COMMrepository.insertCodeMetadata(d.code_metadata.get(i).getId(), d.code_metadata.get(i).getDescription(), d.code_metadata.get(i).getLanguage_id(), d.code_metadata.get(i).getCode_id());
			    		  d.code_metadata.get(i+1).setId(COMMrepository.selectCodeMetadata()+1);
			    		  COMMrepository.insertCodeMetadata(d.code_metadata.get(i+1).getId(), d.code_metadata.get(i+1).getDescription(), d.code_metadata.get(i+1).getLanguage_id(), d.code_metadata.get(i).getCode_id());
			    		  i++;
			    	  }else {
			    		  d.code_metadata.get(i).setId(COMMrepository.selectCodeMetadata()+1);
			    		  d.code_metadata.get(i).setCode_id(COMMrepository.selectCodeID("%".concat(d.code_metadata.get(i).getDescription()), "%".concat(String.valueOf(country_id)), pivote)); 
			    		  pivote = d.code_metadata.get(i).getCode_id()-1;
			    		  COMMrepository.insertCodeMetadata(d.code_metadata.get(i).getId(), d.code_metadata.get(i).getDescription(), d.code_metadata.get(i).getLanguage_id(), d.code_metadata.get(i).getCode_id());
			    	  }
			    	  i++;
			      }
			      
			      //insert in Special Campaign Master
			      i = 0;
			      while(i < d.special_campaign_master.size()) {
			    	  d.special_campaign_master.get(i).setId(SCMMrepository.selectSpecialCampaignMaster()+1);
			    	  SCMMrepository.insertSpecialCampaignMaster(d.special_campaign_master.get(i).getId(), d.special_campaign_master.get(i).getCountry_id(), d.special_campaign_master.get(i).getVersion(), d.special_campaign_master.get(i).getCampaign_name(), d.special_campaign_master.get(i).getCampaign_desc(), d.special_campaign_master.get(i).getCreated_date(), d.special_campaign_master.get(i).getLast_updated_date(), d.special_campaign_master.get(i).getCreated_by(), d.special_campaign_master.get(i).getLast_updated_by());
			    
			    	 i++;
			      }
			      //insert in app_build_info
			      i = 0;
			      while(i < d.app_build_info.size()) {
			    	  d.app_build_info.get(i).setId(ABIMrepository.selectAppBuildInfo()+1);
			    	  ABIMrepository.insertAppBuildInfo(d.app_build_info.get(i).getId(), d.app_build_info.get(i).getCreated_date(), d.app_build_info.get(i).getLast_upated_date(), d.app_build_info.get(i).getApp_version(), d.app_build_info.get(i).getBuild_description(), d.app_build_info.get(i).isIs_force_update(), d.app_build_info.get(i).getOperating_system(), d.app_build_info.get(i).getCountry_id(), d.app_build_info.get(i).getOld_id());
			    
			    	 i++;
			      }
			      
			      //insert in insights_data_sync_log
			      i = 0;
			      while(i < d.insights_data_sync_log.size()) {
			    	  d.insights_data_sync_log.get(i).setId(IDSLMrepository.selectInsightsDataSyncLog()+1);
			    	  IDSLMrepository.insertInsightsDataSyncLog(d.insights_data_sync_log.get(i).getId(), d.insights_data_sync_log.get(i).getInsights_data_sync_date(), d.insights_data_sync_log.get(i).getCountry_id(), d.insights_data_sync_log.get(i).getOld_id(), d.insights_data_sync_log.get(i).getApi_key());
			    
			    	 i++;
			      }
		
	}
	 public int getId() {
		 int a = CMrepository.selectCountry()+1;
		 return a;
	 }

}
//<dependency>
//<groupId>org.springframework.cloud</groupId>
//<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
//</dependency>
