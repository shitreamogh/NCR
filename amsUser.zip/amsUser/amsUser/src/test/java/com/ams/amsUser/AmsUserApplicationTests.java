package com.ams.amsUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmsUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
