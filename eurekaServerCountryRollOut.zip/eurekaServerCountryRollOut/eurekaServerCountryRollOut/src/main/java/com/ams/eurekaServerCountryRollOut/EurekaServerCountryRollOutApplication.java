package com.ams.eurekaServerCountryRollOut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class EurekaServerCountryRollOutApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerCountryRollOutApplication.class, args);
	}

}
