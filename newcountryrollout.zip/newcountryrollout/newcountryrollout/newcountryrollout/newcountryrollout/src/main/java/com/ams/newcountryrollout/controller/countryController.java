package com.ams.newcountryrollout.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.ams.newcountryrollout.helper.ExcelHelper;
import com.ams.newcountryrollout.message.responseMessage;
import com.ams.newcountryrollout.model.data;
import com.ams.newcountryrollout.service.countryService;

@Controller
@RequestMapping("/api/excel")
public class countryController {
	@Autowired
	  countryService fileService;
	@Autowired
	private RestTemplate restTemplate;
	data d = new data();
	  @PostMapping("/upload")
	  public ResponseEntity<responseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
	    String message = "";
	    ResponseEntity<String> message1;
	    if (ExcelHelper.hasExcelFormat(file)) {
//	      try {
	        d = fileService.save(file);
	        long country_id = restTemplate.getForObject("http://localhost:7087/amsUser/getCountryId", Integer.class);
	        System.out.println(country_id);
//	        d.country.get(0).setId(cid);
	        d = fileService.setData( d, country_id);
	        System.out.println(d.country.size());
//	        message1 = restTemplate.postForEntity("http://localhost:7087/amsUser/insert", d, String.class);
//	        message1 = restTemplate.postForEntity("http://localhost:7088/amsProduct/insert", d, String.class);
//	        message1 = restTemplate.postForEntity("http://localhost:7089/amsOrder/insert", d, String.class);
	        message = "Uploaded the file successfully: " + file.getOriginalFilename();
	        return ResponseEntity.status(HttpStatus.OK).body(new responseMessage(message, d));
//	      } catch (Exception e) {
//	        message = "Could not upload the file: " + file.getOriginalFilename() + "!";
//	        return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new responseMessage(message));
//	      }
	    }
	    message = "Please upload an excel file!";
	    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new responseMessage(message, d));
	  }
	  
	  @GetMapping("/getdata")
	  public data getData(){
		  return d;
	  }
}
