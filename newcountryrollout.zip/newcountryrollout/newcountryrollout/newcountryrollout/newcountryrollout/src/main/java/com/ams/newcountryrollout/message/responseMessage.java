package com.ams.newcountryrollout.message;

import com.ams.newcountryrollout.model.data;

public class responseMessage {
	private String message;
	private data d;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public data getD() {
		return d;
	}
	public void setD(data d) {
		this.d = d;
	}
	public responseMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public responseMessage(String message, data d) {
		super();
		this.message = message;
		this.d = d;
	}

	
	

}
