package com.ams.newcountryrollout.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "app_build_info")
public class appBuildInfoModel {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false)
	private Date created_date;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_upated_date")
	private Date last_upated_date;
	@Column(name = "app_version")
	private double app_version;
	@Column(name = "build_description")
	private String build_description;
	@Column(name = "is_force_update")
	private boolean is_force_update;
	@Column(name = "operating_system")
	private String operating_system;
	@Column(name="country_id")
	private long country_id;
	@Column(name="old_id")
	private long old_id;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public Date getLast_upated_date() {
		return last_upated_date;
	}
	public void setLast_upated_date(Date last_upated_date) {
		this.last_upated_date = last_upated_date;
	}
	public double getApp_version() {
		return app_version;
	}
	public void setApp_version(double app_version) {
		this.app_version = app_version;
	}
	public String getBuild_description() {
		return build_description;
	}
	public void setBuild_description(String build_description) {
		this.build_description = build_description;
	}
	public boolean isIs_force_update() {
		return is_force_update;
	}
	public void setIs_force_update(boolean is_force_update) {
		this.is_force_update = is_force_update;
	}
	public String getOperating_system() {
		return operating_system;
	}
	public void setOperating_system(String operating_system) {
		this.operating_system = operating_system;
	}
	public long getCountry_id() {
		return country_id;
	}
	public void setCountry_id(long country_id) {
		this.country_id = country_id;
	}
	public long getOld_id() {
		return old_id;
	}
	public void setOld_id(long old_id) {
		this.old_id = old_id;
	}
	public appBuildInfoModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public appBuildInfoModel(long id, Date created_date, Date last_upated_date, double app_version,
			String build_description, boolean is_force_update, String operating_system, long country_id, long old_id) {
		super();
		this.id = id;
		this.created_date = created_date;
		this.last_upated_date = last_upated_date;
		this.app_version = app_version;
		this.build_description = build_description;
		this.is_force_update = is_force_update;
		this.operating_system = operating_system;
		this.country_id = country_id;
		this.old_id = old_id;
	}
	@Override
	public String toString() {
		return "appBuildInfoModel [id=" + id + ", created_date=" + created_date + ", last_upated_date="
				+ last_upated_date + ", app_version=" + app_version + ", build_description=" + build_description
				+ ", is_force_update=" + is_force_update + ", operating_system=" + operating_system + ", country_id="
				+ country_id + ", old_id=" + old_id + "]";
	}
	
	

}
