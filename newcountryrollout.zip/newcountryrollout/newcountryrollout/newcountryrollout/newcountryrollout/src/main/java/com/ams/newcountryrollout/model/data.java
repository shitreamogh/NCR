package com.ams.newcountryrollout.model;

import java.util.List;

public class data {
	public List<countryModel> country;
	public List<codeCountryModel> code_country;
	public List<locationMetadataModel> location_metadata;
	public List<codeModel> code;
	public List<codeMetadataModel> code_metadata;
	public List<specialCampaignMasterModel> special_campaign_master;
	public List<appBuildInfoModel> app_build_info;
	public List<insightsDataSyncLogModel> insights_data_sync_log;
	public List<productCountry> product_country;
	public List<productInsightsDataSyncLog> product_insights_data_sync_logs;
	public List<orderCountry> order_country;
	public List<orderInsightsDataSyncLog> order_insights_data_sync_logs;
	public List<orderCommissionDetail> order_commission_details;
	
	public data() {
		super();
		// TODO Auto-generated constructor stub
	}

	public data(List<countryModel> country, List<codeCountryModel> code_country,
			List<locationMetadataModel> location_metadata, List<codeModel> code, List<codeMetadataModel> code_metadata,
			List<specialCampaignMasterModel> special_campaign_master, List<appBuildInfoModel> app_build_info,
			List<insightsDataSyncLogModel> insights_data_sync_log, List<productCountry> product_country,
			List<productInsightsDataSyncLog> product_insights_data_sync_logs, List<orderCountry> order_country,
			List<orderInsightsDataSyncLog> order_insights_data_sync_logs,
			List<orderCommissionDetail> order_commission_details) {
		super();
		this.country = country;
		this.code_country = code_country;
		this.location_metadata = location_metadata;
		this.code = code;
		this.code_metadata = code_metadata;
		this.special_campaign_master = special_campaign_master;
		this.app_build_info = app_build_info;
		this.insights_data_sync_log = insights_data_sync_log;
		this.product_country = product_country;
		this.product_insights_data_sync_logs = product_insights_data_sync_logs;
		this.order_country = order_country;
		this.order_insights_data_sync_logs = order_insights_data_sync_logs;
		this.order_commission_details = order_commission_details;
	}
	
}
