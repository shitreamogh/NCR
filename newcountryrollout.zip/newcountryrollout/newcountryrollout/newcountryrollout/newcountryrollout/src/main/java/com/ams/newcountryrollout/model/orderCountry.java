package com.ams.newcountryrollout.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "country")
public class orderCountry {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Column(name = "code")
	private String code; //(user/text)
	@Column(name = "description")
	private String description;
	@Column(name = "android_app_name")
	private String android_app_name;
	@Column(name = "ios_app_name")
	private String ios_app_name;
	@Column(name = "server_api_key")
	private String server_api_key;
	@Column(name = "kezzler_api_url")
	private String kezzler_api_url;
	@Column(name = "kezzler_header")
	private String kezzler_header;
	@Column(name = "unit_of_measure")
	private String unit_of_measure;
	@Column(name = "integration_type")
	private String integration_type;
	@Column(name = "is_duplicate_qr_allowed")
	private boolean is_duplicate_qr_allowed;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAndroid_app_name() {
		return android_app_name;
	}
	public void setAndroid_app_name(String android_app_name) {
		this.android_app_name = android_app_name;
	}
	public String getIos_app_name() {
		return ios_app_name;
	}
	public void setIos_app_name(String ios_app_name) {
		this.ios_app_name = ios_app_name;
	}
	public String getServer_api_key() {
		return server_api_key;
	}
	public void setServer_api_key(String server_api_key) {
		this.server_api_key = server_api_key;
	}
	public String getKezzler_api_url() {
		return kezzler_api_url;
	}
	public void setKezzler_api_url(String kezzler_api_url) {
		this.kezzler_api_url = kezzler_api_url;
	}
	public String getKezzler_header() {
		return kezzler_header;
	}
	public void setKezzler_header(String kezzler_header) {
		this.kezzler_header = kezzler_header;
	}
	public String getUnit_of_measure() {
		return unit_of_measure;
	}
	public void setUnit_of_measure(String unit_of_measure) {
		this.unit_of_measure = unit_of_measure;
	}
	public String getIntegration_type() {
		return integration_type;
	}
	public void setIntegration_type(String integration_type) {
		this.integration_type = integration_type;
	}
	public boolean isIs_duplicate_qr_allowed() {
		return is_duplicate_qr_allowed;
	}
	public void setIs_duplicate_qr_allowed(boolean is_duplicate_qr_allowed) {
		this.is_duplicate_qr_allowed = is_duplicate_qr_allowed;
	}
	public orderCountry() {
		super();
		// TODO Auto-generated constructor stub
	}
	public orderCountry(long id, String code, String description, String android_app_name, String ios_app_name,
			String server_api_key, String kezzler_api_url, String kezzler_header, String unit_of_measure,
			String integration_type, boolean is_duplicate_qr_allowed) {
		super();
		this.id = id;
		this.code = code;
		this.description = description;
		this.android_app_name = android_app_name;
		this.ios_app_name = ios_app_name;
		this.server_api_key = server_api_key;
		this.kezzler_api_url = kezzler_api_url;
		this.kezzler_header = kezzler_header;
		this.unit_of_measure = unit_of_measure;
		this.integration_type = integration_type;
		this.is_duplicate_qr_allowed = is_duplicate_qr_allowed;
	}
	

}
