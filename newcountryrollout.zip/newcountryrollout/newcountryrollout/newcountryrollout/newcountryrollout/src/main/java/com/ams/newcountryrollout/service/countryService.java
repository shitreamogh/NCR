package com.ams.newcountryrollout.service;

import java.io.IOException;
import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ams.newcountryrollout.helper.ExcelHelper;
import com.ams.newcountryrollout.model.data;

@Service
public class countryService {
	  long country_id;
	  data d = new data();
	  public data save(MultipartFile file) {
			      try {
					d = ExcelHelper.excelToams_user(file.getInputStream());
				
			      System.out.println(d.code_country.get(0).getCode_id());
			      			      
	    } catch (IOException e) {
						// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return d;
	}
	  public data setData(data d, long country_id) {
		  int i = 0;
		  //ams_user country
		  d.country.get(0).setId(country_id);
		  //ams_user code_country
		  for(i = 0; i < d.code_country.size(); i++) {
			  d.code_country.get(i).setCountry_id(country_id);
			  d.code_country.get(i).setCode_id(d.code_country.get(i).getCode_id().concat(String.valueOf(country_id)));
		  }
		  //ams_user location_metadata
		  for(i = 0; i < d.location_metadata.size(); i++) {
			  d.location_metadata.get(i).setCountry_id(country_id);
			  d.location_metadata.get(i).setLocation_hierarchy_level("LEVEL"+(i+1));
			  d.location_metadata.get(i).setCountry_name(d.country.get(0).getDescription());
		  }
		  //ams_user code
		  for(i = 0; i < d.code.size(); i++) {
			  d.code.get(i).setCode(d.code.get(i).getCode().concat(String.valueOf(country_id)));
		  }
		  //ams_user special_campaign_master
		  for(i = 0; i < d.special_campaign_master.size(); i++) {
			  d.special_campaign_master.get(i).setCountry_id(country_id);
			  d.special_campaign_master.get(i).setCreated_date(new Date());
	    	  d.special_campaign_master.get(i).setLast_updated_date(new Date());
		  }
		  //ams_user app_build_info
		  for(i = 0; i < d.app_build_info.size(); i++) {
			  d.app_build_info.get(i).setCountry_id(country_id);
			  d.app_build_info.get(i).setCreated_date(new Date());
	    	  d.app_build_info.get(i).setLast_upated_date(new Date());
		  }
		  //ams_user insights_data_sync_log
		  for(i = 0; i < d.insights_data_sync_log.size(); i++) {
			  d.insights_data_sync_log.get(i).setCountry_id(country_id);
			  d.insights_data_sync_log.get(i).setInsights_data_sync_date(new Date());
		  }
		  
		  //ams_product country
		  d.product_country.get(0).setId(country_id);
		  //ams_product insights_data_sync_log
		  for(i = 0; i < d.product_insights_data_sync_logs.size(); i++) {
			  d.product_insights_data_sync_logs.get(i).setCountry_id(country_id);
			  d.product_insights_data_sync_logs.get(i).setInsights_data_sync_date(new Date());
		  }
		  
		  //ams_order country
		  d.order_country.get(0).setId(country_id);
		  d.order_country.get(0).setCode(d.country.get(0).getCode());
	      d.order_country.get(0).setDescription(d.country.get(0).getDescription());
	      d.order_country.get(0).setUnit_of_measure(d.country.get(0).getUnit_of_measure());
		  //ams_order insights_data_sync_log
		  for(i = 0; i < d.order_insights_data_sync_logs.size(); i++) {
			  d.order_insights_data_sync_logs.get(i).setCountry_id(country_id);
			  d.order_insights_data_sync_logs.get(i).setInsights_data_sync_date(new Date());
		  }
		  //ams_order commission_details
		  for(i = 0; i < d.order_commission_details.size(); i++) {
			  d.order_commission_details.get(i).setCountry_id(country_id);
		  }
		  
		  return d;
	  }
}
