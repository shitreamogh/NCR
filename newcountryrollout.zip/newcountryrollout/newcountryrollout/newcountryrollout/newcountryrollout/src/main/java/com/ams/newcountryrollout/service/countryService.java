package com.ams.newcountryrollout.service;

import java.io.IOException;
import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ams.newcountryrollout.helper.ExcelHelper;
import com.ams.newcountryrollout.model.data;

@Service
public class countryService {
	  long country_id;
	  data d = new data();
	  public data save(MultipartFile file) {
			      try {
					d = ExcelHelper.excelToams_user(file.getInputStream());
				
			      System.out.println(d.codeCountry.get(0).getCode_id());
			      			      
	    } catch (IOException e) {
						// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return d;
	}
	  public data setData(data d, long country_id) {
		  int i = 0;
		  //ams_user country
		  d.country.get(0).setId(country_id);
		  //ams_user code_country
		  for(i = 0; i < d.codeCountry.size(); i++) {
			  d.codeCountry.get(i).setCountry_id(country_id);
			  d.codeCountry.get(i).setCode_id(d.codeCountry.get(i).getCode_id().concat(String.valueOf(country_id)));
		  }
		  //ams_user location_metadata
		  for(i = 0; i < d.locationMetadata.size(); i++) {
			  d.locationMetadata.get(i).setCountry_id(country_id);
			  d.locationMetadata.get(i).setLocation_hierarchy_level("LEVEL"+(i+1));
			  d.locationMetadata.get(i).setCountry_name(d.country.get(0).getDescription());
		  }
		  //ams_user code
		  for(i = 0; i < d.code.size(); i++) {
			  d.code.get(i).setCode(d.code.get(i).getCode().concat(String.valueOf(country_id)));
		  }
		  //ams_user special_campaign_master
		  for(i = 0; i < d.specialCampaignMaster.size(); i++) {
			  d.specialCampaignMaster.get(i).setCountry_id(country_id);
			  d.specialCampaignMaster.get(i).setCreated_date(new Date());
	    	  d.specialCampaignMaster.get(i).setLast_updated_date(new Date());
		  }
		  //ams_user app_build_info
		  for(i = 0; i < d.appBuildInfo.size(); i++) {
			  d.appBuildInfo.get(i).setCountry_id(country_id);
			  d.appBuildInfo.get(i).setCreated_date(new Date());
	    	  d.appBuildInfo.get(i).setLast_upated_date(new Date());
		  }
		  //ams_user insights_data_sync_log
		  for(i = 0; i < d.insightsDataSyncLog.size(); i++) {
			  d.insightsDataSyncLog.get(i).setCountry_id(country_id);
			  d.insightsDataSyncLog.get(i).setInsights_data_sync_date(new Date());
		  }
		  
		  //ams_product country
		  d.productCountry.get(0).setId(country_id);
		  //ams_product insights_data_sync_log
		  for(i = 0; i < d.productInsightsDataSyncLogs.size(); i++) {
			  d.productInsightsDataSyncLogs.get(i).setCountry_id(country_id);
			  d.productInsightsDataSyncLogs.get(i).setInsights_data_sync_date(new Date());
		  }
		  
		  //ams_order country
		  d.orderCountry.get(0).setId(country_id);
		  d.orderCountry.get(0).setCode(d.country.get(0).getCode());
	      d.orderCountry.get(0).setDescription(d.country.get(0).getDescription());
	      d.orderCountry.get(0).setUnit_of_measure(d.country.get(0).getUnit_of_measure());
		  //ams_order insights_data_sync_log
		  for(i = 0; i < d.orderInsightsDataSyncLogs.size(); i++) {
			  d.orderInsightsDataSyncLogs.get(i).setCountry_id(country_id);
			  d.orderInsightsDataSyncLogs.get(i).setInsights_data_sync_date(new Date());
		  }
		  //ams_order commission_details
		  for(i = 0; i < d.orderCommissionDetails.size(); i++) {
			  d.orderCommissionDetails.get(i).setCountry_id(country_id);
		  }
		  
		  return d;
	  }
}
