package com.ams.newcountryrollout.service;

import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ams.newcountryrollout.helper.ExcelHelper;
import com.ams.newcountryrollout.model.data;
import com.ams.newcountryrollout.repository.appBuildInfoModelRepository;
import com.ams.newcountryrollout.repository.codeCountryModelRepository;
import com.ams.newcountryrollout.repository.codeMetadataRepository;
import com.ams.newcountryrollout.repository.codeModelRepository;
import com.ams.newcountryrollout.repository.countryModelRepository;
import com.ams.newcountryrollout.repository.insightsDataSyncLogModelRepository;
import com.ams.newcountryrollout.repository.locationMetadataModelRepository;
import com.ams.newcountryrollout.repository.specialCampaignMasterRepository;

@Service
public class countryService {
	 @Autowired
	  countryModelRepository CMrepository;
	 @Autowired
	  codeCountryModelRepository CCMrepository;
	 @Autowired
	  locationMetadataModelRepository LMrepository;
	 @Autowired
	  codeModelRepository COMrepository;
	 @Autowired
	  codeMetadataRepository COMMrepository;
	 @Autowired
	 specialCampaignMasterRepository SCMMrepository;
	 @Autowired
	 appBuildInfoModelRepository ABIMrepository;
	 @Autowired
	 insightsDataSyncLogModelRepository IDSLMrepository;
	  long country_id;
	  data d = new data();
	  public void save(MultipartFile file) {
	    try {
//	      List<countryModel> CModel = ExcelHelper.excelToams_user(file.getInputStream());
//	      List<codeCountryModel> CCModel = null ;//ExcelHelper.excelToams_user(file.getInputStream());
//	      List<locationMetadataModel> LMModel = null;
	      d = ExcelHelper.excelToams_user(file.getInputStream());
	      System.out.println(d.codeCountry.get(0).getCode_id());
	      
	      //insert data in country
	      d.country.get(0).setId(CMrepository.selectCountry()+1);
	      country_id = d.country.get(0).getId();
//	      System.out.println(CModel.get(0).getId());
	      CMrepository.insertcountry(d.country.get(0).getId(), d.country.get(0).getCode(), d.country.get(0).getDescription(), 
	    		  d.country.get(0).getLanguage(), d.country.get(0).getFarmer_language(), d.country.get(0).getApac_code(), 
	    		  d.country.get(0).getUnit_of_measure(), d.country.get(0).getLoc_optimization(), d.country.get(0).getUnified_app(), 
	    		  d.country.get(0).getCurrency(), d.country.get(0).getCountry_code(), d.country.get(0).getS3_location(), 
	    		  d.country.get(0).getApac_url(), d.country.get(0).getDynamic_commission(), d.country.get(0).isMaintenance_flag(), 
	    		  d.country.get(0).getDc_apac_url(), d.country.get(0).getAgro_url(), d.country.get(0).getAgro_username(), 
	    		  d.country.get(0).getAgro_password(), d.country.get(0).getSender_id(), d.country.get(0).getZone_id(), 
	    		  d.country.get(0).getIs_p360_applicable(), d.country.get(0).getApp_version(), d.country.get(0).getApac_country_code(), 
	    		  d.country.get(0).getCurrancy(), d.country.get(0).getDynamic_commision(), d.country.get(0).isMultilingual_enabled(), 
	    		  d.country.get(0).getIs_legal_agreement_enabled());
	      
	      //Insert Data in code_country
	      int i = 0;
	      while(i < d.codeCountry.size()) {
	    	  d.codeCountry.get(i).setId(CCMrepository.selectCodeCountry()+1);
	    	  d.codeCountry.get(i).setCountry_id(country_id);
	    	  CCMrepository.insertCodeCountry(d.codeCountry.get(i).getId(), d.codeCountry.get(i).getCountry_id(), d.codeCountry.get(i).getCode_id().concat(String.valueOf(country_id)));
	    	  i++;
	      }
	      
	      //insert data in location_metadata
	      i = 0;
	      while(i < d.locationMetadata.size()) {
	    	  d.locationMetadata.get(i).setId(LMrepository.selectLocationMetadata()+1);
	    	  d.locationMetadata.get(i).setLocation_hierarchy_level("LEVEL"+(i+1));
	    	  d.locationMetadata.get(i).setCountry_id(country_id);
	    	  LMrepository.insertLocationMetadata(d.locationMetadata.get(i).getId(), d.locationMetadata.get(i).getCountry_id(), d.locationMetadata.get(i).getLocation_hierarchy_level(), d.locationMetadata.get(i).getLocation_hierarchy_name(), d.locationMetadata.get(i).getCountry_name(), d.locationMetadata.get(i).getApac_hierarchy_name());
	    	  i++;
	      }
	      //insert data in code
	      i = 0;
	      while(i < d.code.size()) {
	    	  d.code.get(i).setId(COMrepository.selectCode()+1);
	    	  COMrepository.insertCode(d.code.get(i).getId(), d.code.get(i).getCode().concat(String.valueOf(country_id)), d.code.get(i).getDescription(), d.code.get(i).getValue(), d.code.get(i).getLanguage());
	    
	    	 i++;
	      }
	      //insert in location_metadata
	      i = 0;
	      long pivote = 0;
	      while(i < d.codeMetadata.size()) {
	    	  if(d.country.get(0).isMultilingual_enabled()) {
	    		  d.codeMetadata.get(i).setId(COMMrepository.selectCodeMetadata()+1);
	    		  d.codeMetadata.get(i).setCode_id(COMMrepository.selectCodeID("%".concat(d.codeMetadata.get(i).getDescription()), "%".concat(String.valueOf(country_id)), pivote));
	    		  pivote = d.codeMetadata.get(i).getCode_id()-1;
	    		  COMMrepository.insertCodeMetadata(d.codeMetadata.get(i).getId(), d.codeMetadata.get(i).getDescription(), d.codeMetadata.get(i).getLanguage_id(), d.codeMetadata.get(i).getCode_id());
	    		  d.codeMetadata.get(i+1).setId(COMMrepository.selectCodeMetadata()+1);
	    		  COMMrepository.insertCodeMetadata(d.codeMetadata.get(i+1).getId(), d.codeMetadata.get(i+1).getDescription(), d.codeMetadata.get(i+1).getLanguage_id(), d.codeMetadata.get(i).getCode_id());
	    		  i++;
	    	  }else {
	    		  d.codeMetadata.get(i).setId(COMMrepository.selectCodeMetadata()+1);
	    		  d.codeMetadata.get(i).setCode_id(COMMrepository.selectCodeID("%".concat(d.codeMetadata.get(i).getDescription()), "%".concat(String.valueOf(country_id)), pivote)); 
	    		  pivote = d.codeMetadata.get(i).getCode_id()-1;
	    		  COMMrepository.insertCodeMetadata(d.codeMetadata.get(i).getId(), d.codeMetadata.get(i).getDescription(), d.codeMetadata.get(i).getLanguage_id(), d.codeMetadata.get(i).getCode_id());
	    	  }
	    	  i++;
	      }
	      
	      //insert in Special Campaign Master
	      i = 0;
	      while(i < d.specialCampaignMaster.size()) {
	    	  d.specialCampaignMaster.get(i).setId(SCMMrepository.selectSpecialCampaignMaster()+1);
	    	  d.specialCampaignMaster.get(i).setCreated_date(new Date());
	    	  d.specialCampaignMaster.get(i).setLast_updated_date(new Date());
	    	  d.specialCampaignMaster.get(i).setCountry_id(country_id);
	    	  SCMMrepository.insertSpecialCampaignMaster(d.specialCampaignMaster.get(i).getId(), d.specialCampaignMaster.get(i).getCountry_id(), d.specialCampaignMaster.get(i).getVersion(), d.specialCampaignMaster.get(i).getCampaign_name(), d.specialCampaignMaster.get(i).getCampaign_desc(), d.specialCampaignMaster.get(i).getCreated_date(), d.specialCampaignMaster.get(i).getLast_updated_date(), d.specialCampaignMaster.get(i).getCreated_by(), d.specialCampaignMaster.get(i).getLast_updated_by());
	    
	    	 i++;
	      }
	      //insert in app_build_info
	      i = 0;
	      while(i < d.appBuildInfo.size()) {
	    	  d.appBuildInfo.get(i).setId(ABIMrepository.selectAppBuildInfo()+1);
	    	  d.appBuildInfo.get(i).setCreated_date(new Date());
	    	  d.appBuildInfo.get(i).setLast_upated_date(new Date());
	    	  d.appBuildInfo.get(i).setCountry_id(country_id);
	    	  ABIMrepository.insertAppBuildInfo(d.appBuildInfo.get(i).getId(), d.appBuildInfo.get(i).getCreated_date(), d.appBuildInfo.get(i).getLast_upated_date(), d.appBuildInfo.get(i).getApp_version(), d.appBuildInfo.get(i).getBuild_description(), d.appBuildInfo.get(i).isIs_force_update(), d.appBuildInfo.get(i).getOperating_system(), d.appBuildInfo.get(i).getCountry_id(), d.appBuildInfo.get(i).getOld_id());
	    
	    	 i++;
	      }
	      
	      //insert in insights_data_sync_log
	      i = 0;
	      while(i < d.insightsDataSyncLog.size()) {
	    	  d.insightsDataSyncLog.get(i).setId(IDSLMrepository.selectInsightsDataSyncLog()+1);
	    	  d.insightsDataSyncLog.get(i).setInsights_data_sync_date(new Date());
	    	  d.insightsDataSyncLog.get(i).setCountry_id(country_id);
	    	  IDSLMrepository.insertInsightsDataSyncLog(d.insightsDataSyncLog.get(i).getId(), d.insightsDataSyncLog.get(i).getInsights_data_sync_date(), d.insightsDataSyncLog.get(i).getCountry_id(), d.insightsDataSyncLog.get(i).getOld_id(), d.insightsDataSyncLog.get(i).getApi_key());
	    
	    	 i++;
	      }
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store excel data: " + e.getMessage());
	    }
	  }
//	  public List<countryModel> getAllData() {
//	    return CMrepository.findAll();
//	  }

}
