package com.ams.newcountryrollout.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "special_campaign_master")
public class specialCampaignMasterModel {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", updatable = false, nullable = false)
	private long id;
	@Column(name="country_id")
	private long country_id;
	@Column(name = "version")
	private double version;
	@Column(name = "campaign_name")
	private String campaign_name;
	@Column(name = "campaign_desc")
	private String campaign_desc;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false)
	private Date created_date;
	@Temporal(value=TemporalType.TIMESTAMP)
	@Column(name = "last_updated_date")
	private Date last_updated_date;
	@Column(name = "created_by")
	private double created_by;
	@Column(name = "last_updated_by")
	private double last_updated_by;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getCountry_id() {
		return country_id;
	}
	public void setCountry_id(long country_id) {
		this.country_id = country_id;
	}
	public double getVersion() {
		return version;
	}
	public void setVersion(double version) {
		this.version = version;
	}
	public String getCampaign_name() {
		return campaign_name;
	}
	public void setCampaign_name(String campaign_name) {
		this.campaign_name = campaign_name;
	}
	public String getCampaign_desc() {
		return campaign_desc;
	}
	public void setCampaign_desc(String campaign_desc) {
		this.campaign_desc = campaign_desc;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public Date getLast_updated_date() {
		return last_updated_date;
	}
	public void setLast_updated_date(Date last_updated_date) {
		this.last_updated_date = last_updated_date;
	}
	public double getCreated_by() {
		return created_by;
	}
	public void setCreated_by(double created_by) {
		this.created_by = created_by;
	}
	public double getLast_updated_by() {
		return last_updated_by;
	}
	public specialCampaignMasterModel(long id, long country_id, double version, String campaign_name,
			String campaign_desc, Date created_date, Date last_updated_date, double created_by,
			double last_updated_by) {
		super();
		this.id = id;
		this.country_id = country_id;
		this.version = version;
		this.campaign_name = campaign_name;
		this.campaign_desc = campaign_desc;
		this.created_date = created_date;
		this.last_updated_date = last_updated_date;
		this.created_by = created_by;
		this.last_updated_by = last_updated_by;
	}
	public void setLast_updated_by(double last_updated_by) {
		this.last_updated_by = last_updated_by;
	}
	public specialCampaignMasterModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "specialCampaignMasterModel [id=" + id + ", country_id=" + country_id + ", version=" + version
				+ ", campaign_name=" + campaign_name + ", campaign_desc=" + campaign_desc + ", created_date="
				+ created_date + ", last_updated_date=" + last_updated_date + ", created_by=" + created_by
				+ ", last_updated_by=" + last_updated_by + "]";
	}
		
	
}
