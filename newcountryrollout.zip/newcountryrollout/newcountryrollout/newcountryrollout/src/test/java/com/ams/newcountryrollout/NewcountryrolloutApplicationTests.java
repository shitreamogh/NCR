package com.ams.newcountryrollout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewcountryrolloutApplicationTests {

	@Test
	void contextLoads() {
	}

}
